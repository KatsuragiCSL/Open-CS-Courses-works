package lab14lib;

public interface Generator {
	/** Returns a number between -1 and 1 */
	double next();
}