# numc

Here's what I did in project 4:
-